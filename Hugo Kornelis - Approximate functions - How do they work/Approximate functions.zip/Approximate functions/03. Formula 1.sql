CASE WHEN RowNumber1002 = CASE WHEN CeilingTargetRow1004 > 1 
                               THEN CeilingTargetRow1004 
                               ELSE 1
                          END
     THEN TotalDue
     ELSE NULL
END
