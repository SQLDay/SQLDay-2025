USE AdventureWorks2017;

SET STATISTICS IO ON;

-- A simple overview: all orders by salesperson, sorted by the sale total
SELECT   soh.SalesPersonID,
         soh.TotalDue
FROM     Sales.SalesOrderHeader AS soh
WHERE    soh.SalesPersonID IS NOT NULL
ORDER BY soh.SalesPersonID,
         soh.TotalDue;

-- But I don't need this full list.
-- I only want to know, for each salesperson, what the 80% percentile is.
-- (This means the value where 80% of the orders of that salesperson are for less, and 20% are for more)
SELECT soh.SalesPersonID,
       TotalDue,
       PERCENTILE_DISC (0.8) WITHIN GROUP(ORDER BY soh.TotalDue) 
	                                OVER (PARTITION BY soh.SalesPersonID) AS Perc_80
FROM   Sales.SalesOrderHeader AS soh
WHERE  soh.SalesPersonID IS NOT NULL
ORDER BY soh.SalesPersonID,
         soh.TotalDue;

-- Okay, but I don't need all these rows, I only need the percentile
-- Check the execution plan (plus slides) to find out how it works.
-- Look at statistics io output to see the cost of all these Table Spool operators.
SELECT DISTINCT soh.SalesPersonID,
                PERCENTILE_DISC (0.8) WITHIN GROUP(ORDER BY soh.TotalDue)
				                             OVER (PARTITION BY soh.SalesPersonID) AS Perc_80
FROM   Sales.SalesOrderHeader AS soh
WHERE  soh.SalesPersonID IS NOT NULL;

-- There's also a PERCENTILE_CONT. What's the difference?
SELECT DISTINCT soh.SalesPersonID,
                PERCENTILE_DISC (0.8) WITHIN GROUP(ORDER BY soh.TotalDue)
				                             OVER (PARTITION BY soh.SalesPersonID) AS Perc_80,
                PERCENTILE_CONT (0.8) WITHIN GROUP(ORDER BY soh.TotalDue)
				                             OVER (PARTITION BY soh.SalesPersonID) AS Perc_80_CONT
FROM   Sales.SalesOrderHeader AS soh
WHERE  soh.SalesPersonID IS NOT NULL;

-- Look at the execution plan to see how this works.
-- Formulas are different, but general approach ... and hence worktable usage! ... remains the same.
SELECT DISTINCT soh.SalesPersonID,
                PERCENTILE_CONT (0.8) WITHIN GROUP(ORDER BY soh.TotalDue)
				                             OVER (PARTITION BY soh.SalesPersonID) AS Perc_80_CONT
FROM   Sales.SalesOrderHeader AS soh
WHERE  soh.SalesPersonID IS NOT NULL;

-- No worktable is needed when we use approximate functions.
SELECT   soh.SalesPersonID,
         APPROX_PERCENTILE_DISC (0.8) WITHIN GROUP(ORDER BY soh.TotalDue) AS Perc_80,
         APPROX_PERCENTILE_CONT (0.8) WITHIN GROUP(ORDER BY soh.TotalDue) AS Perc_80_CONT
FROM     Sales.SalesOrderHeader AS soh
WHERE    soh.SalesPersonID IS NOT NULL
GROUP BY soh.SalesPersonID;
