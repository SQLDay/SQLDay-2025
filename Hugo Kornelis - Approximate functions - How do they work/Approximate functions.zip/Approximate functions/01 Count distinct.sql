USE AdventureWorks2017;

SET STATISTICS IO ON;

-- For each product, we need the number of distinct customers who bought it.
SELECT     p.ProductID,
           p.Name,
           COUNT (DISTINCT soh.CustomerID) AS NumCustomers
FROM       Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh
   ON      soh.SalesOrderID = sod.SalesOrderID
INNER JOIN Production.Product     AS p
   ON      p.ProductID      = sod.ProductID
GROUP BY   p.ProductID,
           p.Name
OPTION (MAXDOP 1); -- Disable parallelism to keep the execution plan relatively simple

-- The execution plan for the query above logically follows these steps.
WITH CustomersByProduct -- The GROUP BY is logically equivalent to DISTINCT ProductID, CustomerID
  AS (SELECT     sod.ProductID,
                 soh.CustomerID
      FROM       Sales.SalesOrderDetail AS sod
      INNER JOIN Sales.SalesOrderHeader AS soh
         ON      soh.SalesOrderID = sod.SalesOrderID
      GROUP BY   sod.ProductID,
                 soh.CustomerID),
     NumCustomersByProduct
  AS (SELECT   ProductID,
               COUNT (*) AS NumCustomers
      FROM     CustomersByProduct
      GROUP BY ProductID)
SELECT     p.ProductID,
           p.Name,
           ncby.NumCustomers
FROM       NumCustomersByProduct AS ncby
INNER JOIN Production.Product    AS p
   ON      p.ProductID = ncby.ProductID
OPTION (MAXDOP 1);

-- What if we also need the total orders by product?
SELECT     p.ProductID,
           p.Name,
           COUNT (*)                       AS NumOrders, -- This line is added
           COUNT (DISTINCT soh.CustomerID) AS NumCustomers
FROM       Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh
   ON      soh.SalesOrderID = sod.SalesOrderID
INNER JOIN Production.Product     AS p
   ON      p.ProductID      = sod.ProductID
GROUP BY   p.ProductID,
           p.Name
OPTION (MAXDOP 1);

-- Basically still the same logic
WITH CustomersByProduct
  AS (SELECT     sod.ProductID,
                 soh.CustomerID,
                 COUNT (*) AS NumOrderByProductAndCustomer         -- This line is added
      FROM       Sales.SalesOrderDetail AS sod
      INNER JOIN Sales.SalesOrderHeader AS soh
         ON      soh.SalesOrderID = sod.SalesOrderID
      GROUP BY   sod.ProductID,
                 soh.CustomerID),
     NumCustomersByProduct
  AS (SELECT   CustomersByProduct.ProductID,
               COUNT (*)                          AS NumCustomers,
               SUM (NumOrderByProductAndCustomer) AS NumOrders     -- This line is added
      FROM     CustomersByProduct
      GROUP BY CustomersByProduct.ProductID)
SELECT     p.ProductID,
           p.Name,
           ncby.NumOrders,                                         -- This line is added
           ncby.NumCustomers
FROM       NumCustomersByProduct AS ncby
INNER JOIN Production.Product    AS p
   ON      p.ProductID = ncby.ProductID
OPTION (MAXDOP 1);

-- But what if we also want the number of distinct unit prices?
SELECT     p.ProductID,
           p.Name,
           COUNT (*)                       AS NumOrders,
           COUNT (DISTINCT soh.CustomerID) AS NumCustomers,
		   COUNT (DISTINCT sod.UnitPrice)  AS NumPrices     -- This line is added
FROM       Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh
   ON      soh.SalesOrderID = sod.SalesOrderID
INNER JOIN Production.Product     AS p
   ON      p.ProductID      = sod.ProductID
GROUP BY   p.ProductID,
           p.Name
OPTION (MAXDOP 1);

-- Perhaps an approximation is good enough for our purposes?
SELECT     p.ProductID,
           p.Name,
           COUNT (*)                             AS NumOrders,
           APPROX_COUNT_DISTINCT(soh.CustomerID) AS NumCustomers, -- This line is changed
		   APPROX_COUNT_DISTINCT(sod.UnitPrice)  AS NumPrices     -- This line is changed
FROM       Sales.SalesOrderDetail AS sod
INNER JOIN Sales.SalesOrderHeader AS soh
   ON      soh.SalesOrderID = sod.SalesOrderID
INNER JOIN Production.Product     AS p
   ON      p.ProductID      = sod.ProductID
GROUP BY   p.ProductID,
           p.Name
OPTION (MAXDOP 1,
        USE HINT('DISABLE_BATCH_MODE_ADAPTIVE_JOINS')); -- Another hint to keep things simple
