CASE WHEN [CeilingTargetRow1005]=[FloorTargetRow1006] AND [CeilingTargetRow1005]=[TargetRow1004] 
     THEN CASE WHEN [RowNumber1002]=[TargetRow1004]
               THEN [TotalDue] 
               ELSE 0
          END 
     ELSE CASE WHEN [RowNumber1002]=[FloorTargetRow1006] 
               THEN [TotalDue] * ([CeilingTargetRow1005]-[TargetRow1004]) 
               WHEN [RowNumber1002]=[CeilingTargetRow1005] 
               THEN [TotalDue] * ([TargetRow1004]-[FloorTargetRow1006]) 
               ELSE 0
          END 
END
